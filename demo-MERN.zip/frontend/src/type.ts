export interface Article {
    title: string;
    description: string;
    category: string;
    slug: string;
  }
  